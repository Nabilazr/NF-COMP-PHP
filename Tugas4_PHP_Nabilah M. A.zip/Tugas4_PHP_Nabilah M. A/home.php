<?php
$nama = "Nabilah Maulia Azzahra";
$email = "nabilahmauliaazzahra21@gmail.com";
$nomor_telepon = "082324202879";
$alamat = "Pedawang Bae Kudus";
$universitas = "Universitas Muria Kudus";
$jurusan = "Teknik Informatika";
$foto_profil = "fotoku.jpg";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Biodata</title>
</head>
<body>
<style type="text/css">
	body {
		background-image: url(foto.jpg);
		background-repeat: no-repeat;
		background-position: center;
		background-attachment: fixed;
		background-size: 100%;
	}
	.text{
	background-color: rgb(0, 0, 0);
	background-color: rgba(0, 0, 0, 0.4);
	color: pink;
	font-weight: bold;
	border: 7px solid #FFA07A;
  	position: absolute;
  	top: 50%;
  	left: 50%;
  	transform: translate(-50%, -50%);
  	z-index: 5;
  	width: 40%;height: 70%;
  	padding: 25px;
  	border-radius: 15%;
	}
	.foto {
	position: absolute;
	left: 34%;
	top:23%;
	}
	.nama {
	position: absolute;
	left: 25%;
	top: 60%;
	}
</style>
<div class="text">
	<h2 style="border: solid 5px #FFEBCD;background: #FAF0E6;padding: 20px;text-align: center;border-radius: 15px;line-height: 10px;color: #FFA07A;font-size: 25px;"><u>Biodata Ku</u></h2>	
	
	<div class="foto">
	<img align="left" src="<?php echo $foto_profil; ?>" style="width: 150px;height: 150px;border-radius: 45%"></div>
	<br>
	<div class="nama"><h3>
		<font size="3">
		<p><strong>Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <?php echo $nama; ?></p>
        <p><strong>Email&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <?php echo $email; ?></p>
        <p><strong>HP&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <?php echo $nomor_telepon; ?></p>
        <p><strong>Alamat&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <?php echo $alamat; ?></p>
        <p><strong>Jurusan&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <?php echo $jurusan; ?></p>
		     
		
	</h3></div>
</div>
	
</body>
</html>