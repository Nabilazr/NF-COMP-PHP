<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body style="background-color:#F2F2F2;">
    <font face="courier new">
        <h1 align="center"><b></b></h1>
        <p>
        <p>
        <p align="center">
            <img src="1.jpeg" width="150" height="150" alt="foto"/>
            <img src="2.jpeg" width="150" height="150" alt="foto"/>
            <img src="3.jpeg" width="150" height="150" alt="foto"/>
            <img src="4.jpeg" width="150" height="150" alt="foto"/>
            <img src="5.jpeg" width="150" height="150" alt="foto"/>
            <br>
            <img src="https://i.pinimg.com/564x/d6/d9/91/d6d9917f5191d7808240c9d15ad39f2b.jpg" width="150" height="150" alt="foto"/>
            <img src="https://i.pinimg.com/564x/7e/f8/7b/7ef87b571f5c56cc22233a3d5b2ae530.jpg" width="150" height="150" alt="foto"/>
            <img src="https://i.pinimg.com/564x/4a/b4/c8/4ab4c809d4bb0b465d0aee4c573475d4.jpg" width="150" height="150" alt="foto"/>
            <img src="https://i.pinimg.com/564x/e4/1b/f7/e41bf76c13a9b4c95f3ae41450b80e2d.jpg" width="150" height="150" alt="foto"/>
            <img src="https://i.pinimg.com/564x/5b/c3/7c/5bc37cc103afa0b5e0abdbaa7c17ae88.jpg" width="150" height="150" alt="foto"/>
    </font>
    </font>
    </font>
</body>
</html>