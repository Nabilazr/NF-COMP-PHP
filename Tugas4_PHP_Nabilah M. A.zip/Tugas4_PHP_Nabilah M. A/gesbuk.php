<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body style="background-color:#F2F2F2;">
    <!-- <font face="courier new"> -->
        <p>
            <p>
    <h1 align="center"><b>MyStudy</b></h1>
    <p><table border="1" align="center" width="50%">
    <thead align="center" bgcolor="#B5CFD8">
        <tr height="35px" >
            <td ><b>NO</b></td>
            <td ><b>JENJANG</td>
            <td ><b>PENDIDIKAN</td>
        </tr>
    </thead>
    <tbody align="center">
        <tr height="33px">
            <td >&nbsp;1</td>
            <td>&nbsp;SD/MI</td>
            <td>&nbsp;MI NU BANAT KUDUS</td>
        </tr>
        <tr height="33px">
            <td>&nbsp;2</td>
            <td>&nbsp;SMP/MTs</td>
            <td>&nbsp;MTs NU BANAT KUDUS</td>
        </tr>
        <tr height="33px">
            <td>&nbsp;3</td>
            <td>&nbsp;SMA/MA</td>
            <td>&nbsp;SMA N 1 BAE KUDUS</td>
        </tr>
        <tr height="33px">
            <td>&nbsp;4</td>
            <td>&nbsp;S1</td>
            <td>&nbsp;UNIVERSITAS MURIA KUDUS</td>
        </tr></p></font>  
</body>
</html>