<?php
require_once 'mahasiswa.php';

$list_kuliah = [
    "Universitas keyenn",
    "Universitas big small",
    "Universitas debestt",
    "Universitas topp"
];

$list_pelajaran = [
    "UIUX",
    "JavaScript ",
    "PHP",
    "GitHub"
];

$hasil_output = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $kuliah = $_POST['kuliah'];
    $pelajaran = $_POST['pelajaran'];
    $nilai = $_POST['nilai'];


    $mahasiswa = new mahasiswa($nim, $nama, $kuliah, $pelajaran, $nilai);


    $hasil_output = "<h2 align='center'>Output Data</h2>";
    $hasil_output .= "<table border='1' width='50%' align='center'>";
    $hasil_output .= "<thead><tr><th>NIM</th><th>Nama</th><th>Universitas</th><th>Mata Kuliah</th><th>Nilai</th><th>Status</th><th>Grade</th><th>Predikat</th></tr></thead>";
    $hasil_output .= "<tbody>";
    $hasil_output .= "<tr><td>{$mahasiswa->nim}</td><td>{$mahasiswa->nama}</td><td>{$mahasiswa->kuliah}</td><td>{$mahasiswa->pelajaran}</td><td>{$mahasiswa->nilai}</td><td>{$mahasiswa->getStatus()}</td><td>{$mahasiswa->getGrade()}</td><td>{$mahasiswa->getPredikat()}</td></tr>";
    $hasil_output .= "</tbody></table>";
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 5</title>
    <style>
        body {
    font-family: 'Poppins', sans-serif;
    font-weight: 400;
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
    -moz-osx-font-smoothing: grayscale;
    }
    .container {
            width: 50%;
            margin: auto;
            padding: 30px;
            background-color: #B3C8CF;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 70%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-weight: bold;
        }
        input[type="text"], input[type="number"], select {
            width: calc(100% - 6px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #EF1EEDC;
        }
        input[type="submit"] {
            background-color: #EF1EEDC;
            color: black;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #B3C8CF;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        tr:hover {
            background-color: #EEEEEE;
        }
        th {
            background-color: #EEEEEE;
        }
    </style>
</head>
<body>
    <div class="container" id="form-section">
        <h2 align="center">Form Mahasiswa</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
            <div class="form-group">
                <label for="nim">NIM:</label>
                <input type="text" id="nim" name="nim" required>
            </div>
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" id="nama" name="nama" required>
            </div>
            <div class="form-group">
                <label for="kuliah">Universitas:</label>
                <select id="kuliah" name="kuliah" required>
                    <option value="">Pilih Universitas</option>
                    <?php
                    foreach ($list_kuliah as $kuliah) {
                        echo "<option value='$kuliah'>$kuliah</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="pelajaran">Mata Kuliah:</label>
                <select id="pelajaran" name="pelajaran" required>
                    <option value="">Pilih Mata Kuliah</option>
                    <?php
                    foreach ($list_pelajaran as $pelajaran) {
                        echo "<option value='$pelajaran'>$pelajaran</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="nilai">Nilai:</label>
                <input type="number" id="nilai" name="nilai" min="0" max="100" required>
            </div>
            <input type="submit" value="Submit" align="center">
        </form>
    </div>

    <?php if ($_SERVER["REQUEST_METHOD"] == "POST") : ?>
<div align="center" style="margin-top: 20px;">
    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">Kembali</a>
</div>
<?php endif; ?>
    
    <?php echo $hasil_output; ?>
</body>
</html>