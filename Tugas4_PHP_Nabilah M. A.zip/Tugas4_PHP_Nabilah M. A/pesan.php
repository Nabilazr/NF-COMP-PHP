<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    </style>
</head>

<body>
    <section class="py-5">
        <div class="container">
            <h2 style="text-align: center;">Pemesanan</h2>
            <hr>
            <form action="" method="POST" id="belanjaForm">
            <label for="nama" >Nama Pelanggan : &nbsp;</label>
            <input type="text" name="nama" id="nama" placeholder="Nama Pelanggan"><br>

            <label for="produk">Produk : &nbsp;</label>
            <select name="produk" id="produk" onchange="setHarga()">
                <option value="TV">TV</option>
                <option value="KULKAS">KULKAS</option>
                <option value="MESIN CUCI">MESIN CUCI</option>
                <option value="AC">AC</option>
            </select><br>

            <label for="jumlahBeli">Jumlah Beli : &nbsp;</label>
            <input type="number" name="jumlahBeli" id="jumlahBeli" min="1"><br>

            <input type="submit" name="submit" value="Total">
            <?php
                if (isset($_POST['submit'])) {
                    $nama = $_POST['nama'];
                    $produk = $_POST['produk'];
                    $jumlahBeli = $_POST['jumlahBeli'];

                    $satuanHarga = 0;
                    switch($produk) {
                        case "TV":
                            $satuanHarga = 1250000;
                            break;
                        case "Kulkas":
                            $satuanHarga = 2000000;
                            break;
                        case "Mesin Cuci":
                            $satuanHarga = 3000000;
                            break;
                        case "AC":
                            $satuanHarga = 4000000;
                            break;
                    }

                    $totalBelanja = $jumlahBeli * $satuanHarga;
                    $diskon = 0.1 * $totalBelanja;
                    $ppn = 0.1 * ($totalBelanja - $diskon);
                    $hargaBersih = ($totalBelanja - $diskon) + $ppn;

                    echo "<h3>Detail Pembelian:</h3>";
                    echo "Nama Pelanggan: " . $nama . "<br>";
                    echo "Produk: " . $produk . "<br>";
                    echo "Jumlah Beli: " . $jumlahBeli . "<br>";
                    echo "Harga Satuan: " . $satuanHarga . "<br>";
                    echo "Total Belanja: " . $totalBelanja . "<br>";
                    echo "Diskon (10%): " . $diskon . "<br>";
                    echo "PPN (10%): " . $ppn . "<br>";
                    echo "Harga Bersih: " . $hargaBersih . "<br>";
                }
            ?>
        </form>
    </div>
    <script>
    function setHarga() {
        var select = document.getElementById("produk");
        var hargaSatuanInput = document.getElementById("harga_satuan");

        switch (select.value) {
            case "TV":
                hargaSatuanInput.value = 1250000;
                break;
            case "KULKAS":
                hargaSatuanInput.value = 2000000;
                break;
            case "MESIN CUCI":
                hargaSatuanInput.value = 3000000;
                break;
            case "AC":
                hargaSatuanInput.value = 4000000;
                break;
            default:
                hargaSatuanInput.value = 0;
        }
    }
    </script>
    </section>
</body>