<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Nilai Mahasiswa</title>
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <div class="text">
        <h2 style="text-align:center">Data Nilai Mahasiswa</h2>
        <table border="1">
            <thead>
                <tr>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Nilai</th>
                    <th>Grade</th>
                    <th>Predikat</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $nilai_mahasiswa = [
                    ['nim' => '202151208', 'nama' => 'Nabilah', 'nilai' => 97],
                    ['nim' => '202151102', 'nama' => 'Dita', 'nilai' => 95],
                    ['nim' => '202151008', 'nama' => 'Zavira', 'nilai' => 99],
                    ['nim' => '202151788', 'nama' => 'Diana', 'nilai' => 92],
                    ['nim' => '202151211', 'nama' => 'Dhea', 'nilai' => 88],
                    ['nim' => '202151555', 'nama' => 'Safira', 'nilai' => 71],
                    ['nim' => '202151333', 'nama' => 'Dwi', 'nilai' => 48],
                    ['nim' => '202151662', 'nama' => 'Ixora', 'nilai' => 55],
                    ['nim' => '202151712', 'nama' => 'Irzan', 'nilai' => 62],
                    ['nim' => '202151085', 'nama' => 'Diva', 'nilai' => 85]
                ];

                function hitungGrade($nilai) {
                    if ($nilai >= 90) {
                        return 'A';
                    } elseif ($nilai >= 80) {
                        return 'B';
                    } elseif ($nilai >= 70) {
                        return 'C';
                    } elseif ($nilai >= 60) {
                        return 'D';
                    } else {
                        return 'E';
                    }
                }

                function hitungPredikat($grade) {
                    switch ($grade) {
                        case 'A':
                            return 'Memuaskan';
                            break;
                        case 'B':
                            return 'Bagus';
                            break;
                        case 'C':
                            return 'Cukup';
                            break;
                        case 'D':
                            return 'Kurang';
                            break;
                        case 'E':
                            return 'Buruk';
                            break;
                        default:
                            return 'Tidak Valid';
                    }
                }

                $nilai_tertinggi = max(array_column($nilai_mahasiswa, 'nilai'));
                $nilai_terendah = min(array_column($nilai_mahasiswa, 'nilai'));
                $total_nilai = array_sum(array_column($nilai_mahasiswa, 'nilai'));
                $jumlah_mahasiswa = count($nilai_mahasiswa);
                
                foreach ($nilai_mahasiswa as $mahasiswa) {
                    $nim = $mahasiswa['nim'];
                    $nama = $mahasiswa['nama'];
                    $nilai = $mahasiswa['nilai'];
                    $grade = hitungGrade($nilai);
                    $predikat = hitungPredikat($grade);
                    $keterangan = ($grade == 'E') ? 'Tidak Lulus' : 'Lulus';

                    echo "<tr><td>$nim</td><td>$nama</td><td>$nilai</td><td>$grade</td><td>$predikat</td><td>$keterangan</td></tr>";
                }
            ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3">Nilai Tertinggi </th>
                    <th colspan="5"><?php echo $nilai_tertinggi; ?></th>
                </tr>
                <tr>
                    <th colspan="3">Nilai Terendah </th>
                    <th colspan="5"><?php echo $nilai_terendah; ?></th>
                </tr>
                <tr>
                    <th colspan="3">Nilai Rata-rata </th>
                    <th colspan="5"><?php echo round($total_nilai / $jumlah_mahasiswa, 2); ?></th>
                </tr>
                <tr>
                    <th colspan="3">Jumlah Mahasiswa </th>
                    <th colspan="5"><?php echo $jumlah_mahasiswa; ?></th>
                </tr>
                <tr>
                    <th colspan="3">Jumlah Keseluruhan Nilai </th>
                    <th colspan="5"><?php echo $total_nilai; ?></th>
                </tr>
            </tfoot>
        </table>
    </div>
</body>

</html>