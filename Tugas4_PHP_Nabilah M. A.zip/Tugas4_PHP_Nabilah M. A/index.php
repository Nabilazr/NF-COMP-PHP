<?php
//include / include_once -> potongan2 file utuh, berupa html
//require / require_once -> potongan2 file tapi isinya berupa function 
//menggabungkan beberapa file  menjadio satu bentukj file utuh
include_once 'atas.php';
include_once 'isi.php';
include_once 'bawah.php';
?>